# Pinball

Kia ora, welcome to my WASM Project.

This project simulates a game of pinball, using the Rapier2D crate for Rust. It also has a React & TypeScript frontend.

To get started, please ensure npm, rust, and wasm-pack are installed, then run the following commands once you have cloned this repository.

```
npm install

cd wasm_crate

wasm-pack build --target web --out-dir ../public/wasm

cd ..

npm run dev
```

Then navigate to the right localhost url. It should be http://localhost:5173/, however if not, the terminal should tell you.

To play the game, you can simply click the buttons at the bottom of the screen. However, I would recommend using the spacebar, and the left and right arrow keys. 

Thank you for checking out my project