use std::f32::consts::{FRAC_PI_4, FRAC_PI_8};
use wasm_bindgen::prelude::*;
use rapier2d::prelude::*;
use nalgebra::Vector2;

/// The change in time in each step of the simulation. This expects 50 FPS.
const DT: f32 = 1.0 / 50.0;

#[wasm_bindgen]
/// Ball struct containing position, radius, and angle
pub struct Ball {
    pub x: f32,
    pub y: f32,
    pub radius: f32,
    pub angle: f32,
    pub speed: f32,
}

#[wasm_bindgen]
/// Box struct containing position, dimensions, and angle
pub struct Box {
    pub x: f32,
    pub y: f32,
    pub width: f32,
    pub height: f32,
    pub angle: f32,
}

#[wasm_bindgen]
/// Struct containing all components necessary for a physics simulation
pub struct Simulation {
    pub pinball_body: u32,
    pub pinball_collider: u32,
    pub paddle_r_body: u32,
    pub paddle_r_collider: u32,
    pub paddle_l_body: u32,
    pub paddle_l_collider: u32,
    pub launcher_body: u32,
    pub launcher_collider: u32,

    cuboid_obstacles: Vec<u32>,
    ball_obstacles: Vec<u32>,
    slider_body_handle: RigidBodyHandle,

    bodies: RigidBodySet,
    colliders: ColliderSet,
    joints: ImpulseJointSet,
    physics_pipeline: PhysicsPipeline,
    island_manager: IslandManager,
    broad_phase: DefaultBroadPhase,
    narrow_phase: NarrowPhase,
    multibody_joint_set: MultibodyJointSet,
    ccd_solver: CCDSolver,
    query_pipeline: QueryPipeline,
    physics_hooks: (),
    event_handler: (),
    gravity: Vector2<f32>,
    integration_parameters: IntegrationParameters,
}

#[wasm_bindgen]
impl Simulation {
    /// Constructor
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        let mut bodies = RigidBodySet::new();
        let mut colliders = ColliderSet::new();
        let mut joints = ImpulseJointSet::new();

        // Create the pinball
        let pinball_body = RigidBodyBuilder::dynamic()
            .translation(Vector2::new(9.0, -1.0))
            .build();
        let pinball_body_handle = bodies.insert(pinball_body);
        let pinball_collider = ColliderBuilder::ball(0.4).restitution(1.0).density(0.2).build();
        let pinball_collider_handle =
            colliders.insert_with_parent(pinball_collider, pinball_body_handle, &mut bodies);

        // Create the paddles
        let paddle_l_body = RigidBodyBuilder::dynamic()
            .translation(Vector2::new(-1.5, 0.0))
            .build();
        let paddle_l_body_handle = bodies.insert(paddle_l_body);
        let paddle_l_collider = ColliderBuilder::cuboid(1.0, 0.3).density(10.0).build();
        let paddle_l_collider_handle =
            colliders.insert_with_parent(paddle_l_collider, paddle_l_body_handle, &mut bodies);
        let paddle_l_anchor = RigidBodyBuilder::fixed().translation(Vector2::new(-2.5, 0.3)).build();
        let paddle_l_anchor_handle = bodies.insert(paddle_l_anchor);
        let paddle_l_hinge_joint = RevoluteJointBuilder::new()
            .local_anchor1(point![-1.0, 0.3])
            .local_anchor2(point![0.0, 0.0])
            .limits([-FRAC_PI_8, FRAC_PI_8])
            .build();
        joints.insert(
            paddle_l_body_handle,
            paddle_l_anchor_handle,
            paddle_l_hinge_joint,
            true,
        );
        let paddle_r_body = RigidBodyBuilder::dynamic()
            .translation(Vector2::new(1.5, 0.0))
            .build();
        let paddle_r_body_handle = bodies.insert(paddle_r_body);
        let paddle_r_collider = ColliderBuilder::cuboid(1.0, 0.3).density(10.0).build();
        let paddle_r_collider_handle =
            colliders.insert_with_parent(paddle_r_collider, paddle_r_body_handle, &mut bodies);
        let paddle_r_anchor = RigidBodyBuilder::fixed().translation(Vector2::new(2.5, 0.3)).build();
        let paddle_r_anchor_handle = bodies.insert(paddle_r_anchor);
        let paddle_r_hinge_joint = RevoluteJointBuilder::new()
            .local_anchor1(point![1.0, 0.3])
            .local_anchor2(point![0.0, 0.0])
            .limits([-FRAC_PI_8, FRAC_PI_8])
            .build();
        joints.insert(
            paddle_r_body_handle,
            paddle_r_anchor_handle,
            paddle_r_hinge_joint,
            true,
        );

        // Create the launcher
        let launcher_body = RigidBodyBuilder::dynamic()
            .translation(Vector2::new(9.0, -2.0))
            .build();
        let launcher_body_handle = bodies.insert(launcher_body);
        let launcher_collider = ColliderBuilder::cuboid(0.5, 0.5).density(10.0).build();
        let launcher_collider_handle =
            colliders.insert_with_parent(launcher_collider, launcher_body_handle, &mut bodies);
        let launcher_anchor = RigidBodyBuilder::fixed().translation(Vector2::new(9.0, -2.0)).build();
        let launcher_anchor_handle = bodies.insert(launcher_anchor);
        let launcher_prismatic_joint = PrismaticJointBuilder::new(Vector2::y_axis())
            .local_anchor1(point![0.0, 0.0])
            .local_anchor2(point![0.0, 0.0])
            .limits([-5.0, 0.0])
            .build();
        joints.insert(
            launcher_body_handle,
            launcher_anchor_handle,
            launcher_prismatic_joint,
            true,
        );

        // Create the moving obstacles
        let spinner_handle_l = colliders.insert_with_parent(
            ColliderBuilder::cuboid(1.75, 0.3)
                .build(),
            bodies.insert(RigidBodyBuilder::kinematic_velocity_based()
                .translation(vector![-5.0, 10.0])
                .angvel(1.5)
                .build()), 
            &mut bodies);
        let spinner_handle_r = colliders.insert_with_parent(
                ColliderBuilder::cuboid(1.75, 0.3)
                    .build(),
                bodies.insert(RigidBodyBuilder::kinematic_velocity_based()
                    .translation(vector![5.0, 10.0])
                    .angvel(-1.5)
                    .build()), 
                &mut bodies);
        let slider_collider = ColliderBuilder::cuboid(0.5, 0.5)
            .rotation(FRAC_PI_4)
            .build();
        let slider_body_handle = bodies.insert(
            RigidBodyBuilder::kinematic_velocity_based()
                .translation(Vector2::new(0.0, 13.5))
                .linvel(Vector2::new(3.0, 0.0))
                .build());
        let slider_collider_handle = colliders.insert_with_parent(slider_collider, 
            slider_body_handle,
            &mut bodies);
            

        // Create all stationary obstacles and expose them to the frontend, along with the moving obstacles
        let mut cuboid_obstacles = create_cuboid_obstacles(&mut colliders);
        cuboid_obstacles.push(spinner_handle_l.into_raw_parts().0);
        cuboid_obstacles.push(spinner_handle_r.into_raw_parts().0);
        cuboid_obstacles.push(slider_collider_handle.into_raw_parts().0);
        let ball_obstacles = create_ball_obstacles(&mut colliders);

        // Make simulation run using a custom FPS
        let integration_parameters = IntegrationParameters {
            dt: DT,
            ..Default::default()};

        Simulation {
            pinball_body: pinball_body_handle.into_raw_parts().0,
            pinball_collider: pinball_collider_handle.into_raw_parts().0,
            paddle_r_body: paddle_r_body_handle.into_raw_parts().0,
            paddle_r_collider: paddle_r_collider_handle.into_raw_parts().0,
            paddle_l_body: paddle_l_body_handle.into_raw_parts().0,
            paddle_l_collider: paddle_l_collider_handle.into_raw_parts().0,
            launcher_body: launcher_body_handle.into_raw_parts().0,
            launcher_collider: launcher_collider_handle.into_raw_parts().0,
            cuboid_obstacles,
            ball_obstacles,
            slider_body_handle,
            bodies,
            colliders,
            joints,
            physics_pipeline: PhysicsPipeline::new(),
            island_manager: IslandManager::new(),
            broad_phase: DefaultBroadPhase::new(),
            narrow_phase: NarrowPhase::new(),
            multibody_joint_set: MultibodyJointSet::new(),
            ccd_solver: CCDSolver::new(),
            query_pipeline: QueryPipeline::new(),
            physics_hooks: (),
            event_handler: (),
            gravity: Vector2::new(0.0, -9.81),
            integration_parameters,
        }
    }

    /// Progress the simulation by one step
    pub fn step(&mut self) {
        self.check_slider();

        self.physics_pipeline.step(
            &self.gravity,
            &self.integration_parameters,
            &mut self.island_manager,
            &mut self.broad_phase,
            &mut self.narrow_phase,
            &mut self.bodies,
            &mut self.colliders,
            &mut self.joints,
            &mut self.multibody_joint_set,
            &mut self.ccd_solver,
            Some(&mut self.query_pipeline),
            &self.physics_hooks,
            &self.event_handler,
        );
    }  

    /// Get the cuboid colliders for rendering
    /// 
    /// # Returns
    /// 
    /// An array of all stationary cuboids in the simulation 
    pub fn get_cuboid_obstacles(&self) -> Vec<u32> {
        self.cuboid_obstacles.clone()
    }

    /// Get the ball colliders for rendering
    /// 
    /// # Returns
    /// 
    /// An array of all stationary balls in the simulation 
    pub fn get_ball_obstacles(&self) -> Vec<u32> {
        self.ball_obstacles.clone()
    }

    /// Check if the slider obstacle needs to change direction, and do so
    fn check_slider(&mut self) {
        let x = self.bodies[self.slider_body_handle].translation().x;
        if x > 4.0 {
            self.bodies[self.slider_body_handle].set_linvel(Vector2::new(-3.0, 0.0), true);
        } else if x < -4.0 {
            self.bodies[self.slider_body_handle].set_linvel(Vector2::new(3.0, 0.0), true);
        }
    }

    /// Apply an impulse on a rigid body.
    /// 
    /// # Arguments
    /// 
    /// * `handle` - the handle of the rigid body to apply the torque to
    /// * `x_impulse` - the magnitude of the impulse in the direction of x
    /// * `y_impulse` - the magnitude of the impulse in the direction of y
    /// 
    pub fn apply_impulse(&mut self, handle: u32, x_impulse: f32, y_impulse: f32 ) {
        self.bodies[RigidBodyHandle::from_raw_parts(handle, 0)]
            .apply_impulse(Vector2::new(x_impulse, y_impulse), true);
    }

    /// Apply a torque on a rigid body.
    /// 
    /// # Arguments
    /// 
    /// * `handle` - the handle of the rigid body to apply the torque to
    /// * `torque` - the magnitude of the torque
    /// 
    pub fn apply_torque(&mut self, handle: u32, torque: f32 ) {
        self.bodies[RigidBodyHandle::from_raw_parts(handle, 0)]
            .apply_torque_impulse(torque, true);
    }

    /// Get the pinball as a Ball struct
    /// 
    /// # Returns
    /// 
    /// The pinball as a Ball
    pub fn get_pinball(&self) -> Ball {
        let pinball = self.get_ball(self.pinball_collider);

        let speed = self.bodies[RigidBodyHandle::from_raw_parts(self.pinball_body, 0)].linvel().norm();

        Ball {
            speed,
            ..pinball
        }
    }

    /// Get a ball by its collider's handle
    /// 
    /// # Arguments
    /// 
    /// * `handle` - the handle of the ball's collider
    /// 
    /// # Returns
    /// 
    /// The ball as a Ball, if it exists in the simulation
    pub fn get_ball(&self, handle: u32) -> Ball {
        let collider = &self.colliders[ColliderHandle::from_raw_parts(handle, 0)];
        let translation = collider.translation();
        let shape = collider.shape().as_ball().expect("Error: Not a ball");
        let angle = collider.rotation().angle();

        Ball {
            x: translation.x,
            y: translation.y,
            radius: shape.radius,
            angle,
            speed: 0.0
        }
    }

    /// Get a cuboid by its collider's handle
    /// 
    /// # Arguments
    /// 
    /// * `handle` - the handle of the cuboid's collider
    /// 
    /// # Returns
    /// 
    /// The cuboid as a Box, if it exists in the simulation
    pub fn get_box(&self, handle: u32) -> Box {
        let collider = &self.colliders[ColliderHandle::from_raw_parts(handle, 0)];
        let translation = collider.translation();
        let shape = collider.shape().as_cuboid().expect("Error: Not a cuboid");
        let angle = collider.rotation().angle();

        Box {
            x: translation.x,
            y: translation.y,
            width: shape.half_extents.x * 2.0,
            height: shape.half_extents.y * 2.0,
            angle: angle,
        }
    }
}

/// Creates a cuboid collider with a given pivot point, for easier rotation.
/// 
/// # Arguments
/// 
/// * `half_extents` - the half-extents of the cuboid
/// * `translation` - the translation of the cuboid
/// * `pivot` - the pivot point to apply the rotation around, relative to the translation
/// * `angle` - the rotation angle
/// 
/// # Returns
/// 
/// The cuboid collider
fn create_cuboid(
    half_extents: Vector2<f32>,
    translation: Vector2<f32>,
    pivot: Vector2<f32>,
    angle: f32,
) -> Collider {
    let x = translation.x + pivot.x - pivot.x * angle.cos() + pivot.y * angle.sin();
    let y = translation.y + pivot.y - pivot.x * angle.sin() - pivot.y * angle.cos();

    ColliderBuilder::cuboid(half_extents.x, half_extents.y)
        .translation(Vector2::new(x, y))
        .rotation(angle)
        .build()
}

/// Creates all stationary cuboids
/// 
/// # Arguments
/// 
/// * `colliders` - the ColliderSet of the relevant simulation
/// 
/// # Returns
/// 
/// The handles of the cuboids.
/// 
fn create_cuboid_obstacles(colliders: &mut ColliderSet) -> Vec<u32> {
    let mut cuboid_obstacles = Vec::new();

    // Guard rails
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(2.0, 0.3),
                Vector2::new(-4.5, 0.0),
                Vector2::new(2.0, 0.3),
                -FRAC_PI_8,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(2.0, 0.3),
                Vector2::new(4.5, 0.0),
                Vector2::new(-2.0, 0.3),
                FRAC_PI_8,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.3, 1.0),
                Vector2::new(
                    -2.5 - 4.0 * FRAC_PI_8.cos(),
                    1.0 + 4.0 * FRAC_PI_8.sin(),
                ),
                Vector2::new(0.0, 0.0),
                0.025,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.3, 1.0),
                Vector2::new(
                    2.5 + 4.0 * FRAC_PI_8.cos(),
                    1.0 + 4.0 * FRAC_PI_8.sin(),
                ),
                Vector2::new(0.0, 0.0),
                -0.025,
            )
        ).into_raw_parts().0,
    );

    // Game starter
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.5, 12.5),
                Vector2::new(
                    8.0,
                    10.0,
                ),
                Vector2::new(0.0, 0.0),
                0.0,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.5, 13.0),
                Vector2::new(
                    10.0,
                    10.5,
                ),
                Vector2::new(0.0, 0.0),
                0.0,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.5, 14.5),
                Vector2::new(
                    -8.0,
                    12.0,
                ),
                Vector2::new(0.0, 0.0),
                0.0,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(8.0, 0.5),
                Vector2::new(
                    0.0,
                    26.0,
                ),
                Vector2::new(0.0, 0.0),
                0.0,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(2.25, 0.5),
                Vector2::new(
                    9.5,
                    26.5,
                ),
                Vector2::new(-2.25, 0.0),
                -FRAC_PI_4,
            )
        ).into_raw_parts().0,
    );

    // Wall bumps
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.5, 0.5),
                Vector2::new(
                    -7.5,
                    6.0,
                ),
                Vector2::new(0.0, 0.0),
                -FRAC_PI_4,
            )
        ).into_raw_parts().0,
    );
    cuboid_obstacles.push(
        colliders.insert(
            create_cuboid(
                Vector2::new(0.5, 0.5),
                Vector2::new(
                    7.5,
                    6.0,
                ),
                Vector2::new(0.0, 0.0),
                -FRAC_PI_4,
            )
        ).into_raw_parts().0,
    );

    cuboid_obstacles
}

/// Creates all stationary balls
/// 
/// # Arguments
/// 
/// * `colliders` - the ColliderSet of the relevant simulation
/// 
/// # Returns
/// 
/// The handles of the balls.
/// 
fn create_ball_obstacles(colliders: &mut ColliderSet) -> Vec<u32> {
    let mut ball_obstacles = Vec::new();

    // Bumpers
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(0.0, 18.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(1.5, 16.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(-1.5, 16.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(3.0, 18.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(-3.0, 18.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(-1.5, 20.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(1.5, 20.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(4.5, 16.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(-4.5, 16.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(4.5, 20.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );
    
    ball_obstacles.push(
        colliders.insert(ColliderBuilder::ball(0.3)
            .translation(Vector2::new(-4.5, 20.0))
            .restitution(2.0)
            .build()
        ).into_raw_parts().0,
    );    

    ball_obstacles
}
