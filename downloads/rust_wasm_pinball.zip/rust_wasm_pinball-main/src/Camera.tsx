import { useFrame } from "@react-three/fiber";

/**
 * Camera component. This component makes it much easier to have a moving camera.
 */
function Camera({
  position,
  rotation,
}: {
  position: [number, number, number];
  rotation: [number, number, number];
}) {
  useFrame((state) => {
    state.camera.position.set(...position);
    state.camera.rotation.set(...rotation);
    state.camera.updateProjectionMatrix();
  });
  return null;
}

export default Camera;
