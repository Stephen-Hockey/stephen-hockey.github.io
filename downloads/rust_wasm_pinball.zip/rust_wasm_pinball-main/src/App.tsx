import { useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import init, { Simulation } from "../public/wasm/wasm_crate.js";
import { BallMesh, BoxMesh } from "./Meshes.js";
import Camera from "./Camera.js";

function App() {
  const [s, setS] = useState<Simulation | null>(null);
  const [pinballState, setPinballState] = useState({
    y: 0,
    speed: 0,
  });
  const [score, setScore] = useState(0);
  const [highscore, setHighscore] = useState(0);
  const keysHeld = new Set<string>();

  /**
   * Initialise WASM, then initialise the physics simulation.
   * Get highscore from localStorage if it's there
   */
  useEffect(() => {
    init().then(() => {
      console.info("WASM Loaded");
      setS(new Simulation());
    });
    const localHighscore = window.localStorage.getItem("highscore");
    if (localHighscore) {
      setHighscore(parseInt(localHighscore, 10));
    }
  }, []);

  /**
   * Run the game loop using requestAnimationFrame
   */
  useEffect(() => {
    let stepId: number;

    const step = () => {
      if (s) {
        s.step();
        const pinball = s.get_pinball();
        
        // If pinball falls off the screen
        if (pinball.y < -5) {
          setS(new Simulation());
          setScore(0);
        }

        // Score is based on how fast the ball moves.
        setScore((prevScore) => prevScore + Math.floor(pinball.speed));

        setPinballState({
          y: pinball.y,
          speed: pinball.speed,
        });
      }

      stepId = window.requestAnimationFrame(step);
    };
    stepId = window.requestAnimationFrame(step);

    return () => window.cancelAnimationFrame(stepId);
  }, [s]);

  /**
   * Increase highscore and put it in localStorage when score changes
   */ 
  useEffect(() => {
    if (score > highscore) {
      setHighscore(score);
      window.localStorage.setItem("highscore", score.toString());
    }
  }, [score]);

  /**
   * Keyboard controls
   * 
   * Only tapping is effective, holding a key does nothing 
   */
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (keysHeld.has(event.key)) return;
      keysHeld.add(event.key);

      switch (event.key) {
        case "ArrowLeft":
          triggerPaddleL();
          break;
        case "ArrowRight":
          triggerPaddleR();
          break;
        case " ":
          launchPinball();
          break;
        default:
          break;
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      keysHeld.delete(event.key);
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [s]);

  /**
   * Trigger the launchpad that starts the game.
   */
  const launchPinball = () => {
    if (s) {
      s.apply_impulse(s.launcher_body, 0, 250); // Shoots the pinball upward
    }
  };

  /**
   * Trigger the left paddle
   */
  const triggerPaddleL = () => {
    if (s) {
      s.apply_torque(s.paddle_l_body, 150);
    }
  };

  /**
   * Trigger the right paddle
   */
  const triggerPaddleR = () => {
    if (s) {
      s.apply_torque(s.paddle_r_body, -150);
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        height: "90vh",
        width: "min(90vh, 90vw)",
        margin: "0 auto",
        padding: "20px",
        backgroundColor: "grey",
        borderRadius: "10px",
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          width: "100%",
          marginBottom: "10px",
        }}
      >
        <Box
          sx={{
            fontSize: "20px",
          }}
        >
          Score: {score}
        </Box>
        <Box
          sx={{
            fontSize: "20px",
          }}
        >
          Highscore: {highscore}
        </Box>
      </Box>
      <Canvas
        style={{
          background: "white",
        }}
      >
        <Camera position={[0, Math.max(0, pinballState.y + 5), 14]} rotation={[0, 0, 0]} />
        <ambientLight />
        <directionalLight position={[0, 0, 10]} />

        {s &&
          (() => {
            const pinball = s.get_pinball();
            return (
              <BallMesh
                x={pinball.x}
                y={pinball.y}
                z={0}
                radius={pinball.radius}
                pitch={0}
                yaw={0}
                roll={pinball.angle}
                texturePath="/images/steel.jpg"
              />
            );
          })()}
        {s &&
          (() => {
            const paddleL = s.get_box(s.paddle_l_collider);
            const paddleR = s.get_box(s.paddle_r_collider);
            return (
              <>
                <BoxMesh
                  x={paddleL.x}
                  y={paddleL.y}
                  z={0}
                  width={paddleL.width}
                  height={paddleL.height}
                  depth={1.2}
                  pitch={0}
                  yaw={0}
                  roll={paddleL.angle}
                  texturePath="/images/wood.jpg"
                />
                <BoxMesh
                  x={paddleR.x}
                  y={paddleR.y}
                  z={0}
                  width={paddleR.width}
                  height={paddleR.height}
                  depth={1.2}
                  pitch={0}
                  yaw={0}
                  roll={paddleR.angle}
                  texturePath="/images/wood.jpg"
                />
              </>
            );
          })()}
        {s &&
          (() => {
            const launcher = s.get_box(s.launcher_collider);
            return (
              <>
                <BoxMesh
                  x={launcher.x}
                  y={launcher.y}
                  z={0}
                  width={launcher.width}
                  height={launcher.height}
                  depth={1.2}
                  pitch={0}
                  yaw={0}
                  roll={launcher.angle}
                  texturePath="/images/wood.jpg"
                />
              </>
            );
          })()}
        {s &&
          (() => {
            const cuboidObstacleColliders = Array.from(s.get_cuboid_obstacles());
            return cuboidObstacleColliders.map((value) => {
              const obstacle = s.get_box(value);
              return (
                <BoxMesh
                  key={value}
                  x={obstacle.x}
                  y={obstacle.y}
                  z={0}
                  width={obstacle.width}
                  height={obstacle.height}
                  depth={1.2}
                  pitch={0}
                  yaw={0}
                  roll={obstacle.angle}
                  texturePath="/images/concrete.jpg"
                />
              );
            });
          })()}
        {s &&
          (() => {
            const ballObstacleColliders = Array.from(s.get_ball_obstacles());
            return ballObstacleColliders.map((value) => {
              const obstacle = s.get_ball(value);
              return (
                <BallMesh
                  key={value}
                  x={obstacle.x}
                  y={obstacle.y}
                  z={0}
                  radius={obstacle.radius}
                  pitch={0}
                  yaw={0}
                  roll={0}
                  texturePath="/images/red.jpg"
                />
              );
            });
          })()}
      </Canvas>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: "20px",
          margin: "20px",
        }}
      >
        <Button variant="contained" color="success" onClick={launchPinball}>
          Play!
        </Button>
        <Button variant="contained" color="primary" onClick={triggerPaddleL}>
          Left
        </Button>
        <Button variant="contained" color="primary" onClick={triggerPaddleR}>
          Right
        </Button>
      </Box>
      (or use spacebar and arrow keys)
    </Box>
  );
}

export default App;