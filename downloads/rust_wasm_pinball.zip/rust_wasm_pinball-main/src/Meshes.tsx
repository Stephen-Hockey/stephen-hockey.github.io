import { useLoader } from "@react-three/fiber";
import { TextureLoader } from "three";

interface BallMeshProps {
  x: number;
  y: number;
  z: number, 
  radius: number;
  pitch: number;
  yaw: number;
  roll: number;
  texturePath: string;
}


/**
 * BallMesh component making it much easier to render the pinball and other ball-shaped colliders.
 */
const BallMesh: React.FC<BallMeshProps> = ({ x, y, z, radius, pitch, yaw, roll, texturePath }) => {
  const texture = useLoader(TextureLoader, texturePath);

  return (
    <mesh position={[x, y, z]} rotation={[pitch, yaw, roll]}>
      <sphereGeometry args={[radius, 32, 32]} />
      <meshStandardMaterial map={texture} />
    </mesh>
  );
};

interface BoxMeshProps {
  x: number;
  y: number;
  z: number;
  width: number;
  height: number;
  depth: number;
  pitch: number;
  yaw: number;
  roll: number;
  texturePath: string;
}

/**
 * BoxMesh component making it much easier to render the cuboid-shaped colliders.
 */
const BoxMesh: React.FC<BoxMeshProps> = ({
  x, 
  y, 
  z, 
  width, 
  height, 
  depth, 
  pitch, 
  yaw, 
  roll,
  texturePath
}) => {
  const texture = useLoader(TextureLoader, texturePath);
  return (
    <mesh position={[x, y, z]} rotation={[pitch, yaw, roll]}>
      <boxGeometry args={[width, height, depth]} />
      <meshStandardMaterial map={texture} />
    </mesh>
  );
};

export { BallMesh, BoxMesh };
