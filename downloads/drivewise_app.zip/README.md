# DriveWise
Welcome to DriveWise! Your new favourite road safety app.
This README file includes some useful information to help you get started with DriveWise.

## Authors
- Luke Edwards
- Imogen Keeling
- Kendra Van Loon
- Joseph Hendry
- Bella Hill
- Stephen Hockey

## Prerequisites
- JDK >= 17 [click here to get the latest stable OpenJDK release (as of writing this README)](https://jdk.java.net/18/)
- To populate the database, you'll need a valid CSV file of crashes. You can find the full 800k dataset and more on the github or in the source download on Stephen's website.
- The app creates and uses a local database, which is part of the reason why `drivewise.jar` is contained within a folder of its own.

## Features
- Route creation for anywhere in Aotearoa, showing you what crashes have happened along your chosen route, and letting
you know the best advice to stay wise on your drive. Or bike that is, or walk even! Three modes of transport, and not only
that, but you will have alternate route options available for every search.
- You can also assess an area and get the same helpful tips - only now you can see it as a heatmap if you so choose.
- A comprehensive table view for you to analyze the raw data.
- Stunning CSS styling

## Run App
- Open a terminal
- Navigate to where your jar file is located with cd
- Run the command `java -jar drivewise.jar` to run DriveWise
- Once running, you can click the 'Upload' button and upload a CSV file of your choice. Please use the CSV file supplemented with this README, or alternatively you can use your own personal CSV file, as long as it shares the same fields as the supplemented CSV file.


![DriveWiseSS.png](src%2Fmain%2Fresources%2Fimg%2FDriveWiseSS.png)
