package seng202.team7.controller;

import javafx.stage.Stage;

/**
 * Class the set the stage for the splash controller.
 */
public class SplashController {

    /**
     * Sets the state.
     *
     * @param mainStage The stage to set.
     */
    public void setMainStage(Stage mainStage) {
    }
}
